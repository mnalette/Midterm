import java.util.ArrayList;
import java.util.List;

public class WorkManager {
    private final List<Worker> workers = new ArrayList<>();

    public void addObserver(Worker worker) {
        workers.add(worker);
    }

    public void notify(WorkItem item) {
        for (Worker worker : workers) {
            WorkItem tmp = worker.notify(item);
            if (tmp != null) {
                item = tmp;
                System.out.println(worker.getWorkerID() 
                    + ": Completed work on WorkItem " + item.getItemID());
            }
        }
    }
}