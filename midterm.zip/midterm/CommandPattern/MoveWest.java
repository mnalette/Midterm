public class MoveWest extends MoveCommand {

    public MoveWest(Player p) {
        super(p, -1, 0);
    }
}