public class Player {
    private int xCoord;
    private int yCoord;

    public Player() {
        this.xCoord = 0;
        this.yCoord = 0;
    }

    public void move(int x, int y) {
        this.xCoord += x;
        this.yCoord += y;
    }

    public String getCoords() {
        return "(" + String.format("%1$2s", this.xCoord) 
                + ", " + String.format("%1$2s", this.yCoord) + ")";
    }
}