public class MoveEast extends MoveCommand {
    protected int x = 1;
    protected int y = 0;

    public MoveEast(Player p) {
        super(p, 1, 0);
    }
}