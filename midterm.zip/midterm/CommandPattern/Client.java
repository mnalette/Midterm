import java.util.Random;

public class Client {
    public static void main(String[] args) {
        Random rng = new Random();
        Player player = new Player();
        CommandInvoker invoker = new CommandInvoker();
        String loc = player.getCoords();
    
        for (int i = 1; i < 51; i++) {
            Command cmd;
            String direction;
    
            switch (rng.nextInt(4) + 1) {
                case 1:
                    cmd = new MoveNorth(player);
                    direction = "NORTH";
                    break;
                case 2:
                    cmd = new MoveEast(player);
                    direction = "EAST";
                    break;
                case 3:
                    cmd = new MoveSouth(player);
                    direction = "SOUTH";
                    break;
                case 4:
                    cmd = new MoveWest(player);
                    direction = "WEST";
                    break;
                default:
                    System.out.println("Invalid direction");
                    return;
            }
    
            invoker.execute(cmd);
            System.out.println( direction + "\t" + loc + " -> "
                    + player.getCoords());
            loc = player.getCoords();
        }
    
        while(invoker.undo()) {
            System.out.println("UNDO\t" + loc + " -> " + player.getCoords());
            loc = player.getCoords();
        }
    }
}