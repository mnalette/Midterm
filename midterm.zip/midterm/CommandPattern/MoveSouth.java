public class MoveSouth extends MoveCommand {

    public MoveSouth(Player p) {
        super(p, 0, -1);
    }
}