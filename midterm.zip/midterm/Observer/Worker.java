public class Worker {
    private long WorkerID;

    public Worker(long id) {
        WorkerID = id;
    }

    public long getWorkerID() {
        return WorkerID;
    }

    public WorkItem notify(WorkItem item) {
        if (item.getItemID() != WorkerID) {
            return null;
        }

        System.out.println("Worker " + WorkerID + " processed WorkItem "
            + item.getItemID() + " message " + item.getMessage());
        item.incrementItemID();
        return item;
    }
}