public class Main {

    public static void main(String[] args) {
        WorkManager manager = new WorkManager();
        for (int i = 1; i < 5; i++) {
            Worker worker = new Worker(i);
            manager.addObserver(worker);
        }

        WorkItem item1 = new WorkItem(1, "first");
        manager.notify(item1);
        WorkItem item2 = new WorkItem(3, "second");
        manager.notify(item2);
        WorkItem item3 = new WorkItem(5, "third");
        manager.notify(item3);
    }
}