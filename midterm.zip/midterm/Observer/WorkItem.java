public class WorkItem {
    private long ItemID;
    private String Message;

    public WorkItem(long id, String message) {
        ItemID = id;
        Message = message;
    }

    public long getItemID() {
        return ItemID;
    }

    public String getMessage() {
        return Message;
    }

    public void incrementItemID() {
        ItemID++;
    }
}