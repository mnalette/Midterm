public interface Command {
    void execute();
    boolean undo();
}