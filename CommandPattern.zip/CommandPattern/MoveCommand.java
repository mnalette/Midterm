public class MoveCommand implements Command {
    protected int xDist = 0;
    protected int yDist = 0;

    private Player player;

    public MoveCommand(Player p, int x, int y) {
        this.player = p;
        this.xDist = x;
        this.yDist = y;
    }

    public void execute() {
        player.move(this.xDist, this.yDist);
    }

    public boolean undo() {
        player.move(-this.xDist, -this.yDist);
        return true;
    }
}