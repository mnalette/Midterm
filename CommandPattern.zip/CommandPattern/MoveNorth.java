public class MoveNorth extends MoveCommand {

    public MoveNorth(Player p) {
        super(p, 0, 1);
    }
}