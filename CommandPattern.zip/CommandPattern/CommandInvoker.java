import java.util.Stack;

public class CommandInvoker {
    private final Stack<Command> commands = new Stack<>();

    public void execute(Command cmd) {
        commands.push(cmd);
        cmd.execute();
    }

    public boolean undo() {
        if (commands.empty()) {
            return false;
        }

        Command cmd = commands.pop();
        return cmd.undo();
    }
}